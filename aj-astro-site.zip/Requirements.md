# AJ Personal Research Website — Requirements (v0.2)

(See chat for full spec.)
